MONGO_URI = "mongodb://tchyv.com/:27017"  # Update this to your MongoDB URI
DATABASE_NAME = "chatbot_db"     # Replace with your database name