from pydantic import BaseModel

class LoginModel(BaseModel):
    username: str
    password: str

class UserCreateModel(BaseModel):
    username: str
    password: str
    is_active: bool = True
    
class UserModel(BaseModel):
    username: str
    password: str
    email: str

    