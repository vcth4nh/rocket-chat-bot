from datetime import datetime
from pymongo.collection import Collection
from bson import ObjectId
from fastapi import HTTPException
from app.schemas import UserSchema
import hashlib


class UserController:
    user_schema = UserSchema()
    user_list_schema = UserSchema(many=True)

    @staticmethod
    def create_user(data: dict, users_collection: Collection):
        try:
            validated_data = UserController.user_schema.load(data)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid input: {str(e)}")

        if users_collection.find_one({"email": validated_data["email"]}):
            raise HTTPException(status_code=400, detail="Email already registered")
        if users_collection.find_one({"username": validated_data["username"]}):
            raise HTTPException(status_code=400, detail="Username already registered")
        
        hashed_password = hashlib.sha256(validated_data["password"].encode('utf-8')).hexdigest()
        validated_data["password"] = hashed_password

        result = users_collection.insert_one(validated_data)
        validated_data["_id"] = result.inserted_id
        return UserController.user_schema.dump(validated_data)

    @staticmethod
    def get_user_by_id(user_id: str, users_collection: Collection):
        try:
            user = users_collection.find_one({"_id": ObjectId(user_id)})
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid user ID format")

        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        return UserController.user_schema.dump(user)

    @staticmethod
    def get_all_users(users_collection: Collection):
        users = list(users_collection.find())
        return UserController.user_list_schema.dump(users)

    @staticmethod
    def update_user(user_id: str, update_data: dict, users_collection: Collection):
        try:
            update_data["updated_at"] = datetime.utcnow()
            validated_update = UserController.user_schema.load(
                update_data, partial=True
            )
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid input: {str(e)}")

        result = users_collection.update_one(
            {"_id": ObjectId(user_id)}, {"$set": validated_update}
        )
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="User not found")

        updated_user = users_collection.find_one({"_id": ObjectId(user_id)})
        return UserController.user_schema.dump(updated_user)

    @staticmethod
    def delete_user(user_id: str, users_collection: Collection):
        result = users_collection.delete_one({"_id": ObjectId(user_id)})
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="User not found")
        return {"message": "User deleted successfully"}

    @staticmethod
    def search_user_by_username(username: str, users_collection: Collection):
        users = list(
            users_collection.find({"username": {"$regex": username, "$options": "i"}})
        )
        if not users:
            raise HTTPException(status_code=404, detail="No users found")
        return UserController.user_list_schema.dump(users)

    @staticmethod
    def deactivate_user(user_id: str, users_collection: Collection):
        result = users_collection.update_one(
            {"_id": ObjectId(user_id)},
            {"$set": {"is_active": False, "updated_at": datetime.utcnow()}},
        )
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="User not found")
        return {"message": "User deactivated successfully"}

    @staticmethod
    def activate_user(user_id: str, users_collection: Collection):
        result = users_collection.update_one(
            {"_id": ObjectId(user_id)},
            {"$set": {"is_active": True, "updated_at": datetime.utcnow()}},
        )
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="User not found")
        return {"message": "User activated successfully"}
